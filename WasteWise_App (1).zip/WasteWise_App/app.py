import os
import json
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image

APP_DIR = Path(__file__).parent
MODEL_PATH = APP_DIR / "models" / "waste_classifier.keras"
CLASS_PATH = APP_DIR / "models" / "class_names.json"
HISTORY_PATH = APP_DIR / "scan_history.csv"

CLASSES = ["cardboard", "glass", "metal", "paper", "plastic", "trash", "organic"]
BIN_GUIDE = {
    "cardboard": {"bin": "Paper / cardboard recycling", "color": "Blue", "tips": ["Keep cardboard dry and clean.", "Flatten boxes to save space.", "Remove food-soiled sections when possible."]},
    "glass": {"bin": "Glass recycling", "color": "Green", "tips": ["Empty and rinse the container.", "Do not mix broken glass with loose recyclables unless local rules allow it.", "Check local rules for mirrors, ceramics, and light bulbs."]},
    "metal": {"bin": "Metal recycling", "color": "Yellow", "tips": ["Empty and rinse cans.", "Keep hazardous containers separate.", "Check local recycling rules for foil and mixed materials."]},
    "paper": {"bin": "Paper recycling", "color": "Blue", "tips": ["Keep paper dry.", "Avoid recycling greasy or heavily food-soiled paper.", "Remove plastic wrapping where practical."]},
    "plastic": {"bin": "Plastic recycling", "color": "Blue", "tips": ["Empty and rinse the item.", "Check the resin type and local acceptance rules.", "Keep plastic bags out of curbside bins unless accepted locally."]},
    "trash": {"bin": "General waste", "color": "Grey / black", "tips": ["Check whether the item can be reused first.", "Keep batteries, electronics, chemicals, and medical waste out of general waste.", "Follow local disposal rules."]},
    "organic": {"bin": "Wet / organic waste", "color": "Green", "tips": ["Separate food scraps from packaging.", "Use a compost or wet-waste collection if available.", "Do not include plastic or metal packaging."]},
}
BIN_OPTIONS = {
    "Blue — paper/plastic recycling": "recycling",
    "Green — wet/organic waste": "organic",
    "Yellow — metal recycling": "metal",
    "Green — glass recycling": "glass",
    "Grey/black — general waste": "trash",
}

st.set_page_config(page_title="WasteWise | Waste Segregation Detector", page_icon="♻️", layout="wide")

st.markdown("""
<style>
.stApp {background: #f5faf7;}
[data-testid="stSidebar"] {background: #e8f5ee;}
.hero {padding: 1.1rem 1.4rem; border-radius: 18px; background: linear-gradient(120deg,#0b7548,#1ba36a); color: white; margin-bottom: 1rem;}
.hero h1 {color:white; margin:0; font-size:2.1rem;}
.hero p {color:#e8fff2; margin:.35rem 0 0 0;}
.metric-card {background:white; padding:1rem; border-radius:14px; border:1px solid #dcece2;}
.result-good {padding:1rem; border-radius:12px; background:#e5f7ec; border:1px solid #a9dfbd;}
.result-bad {padding:1rem; border-radius:12px; background:#fff1e6; border:1px solid #f6c59e;}
.small-note {color:#5c7065; font-size:.9rem;}
</style>
""", unsafe_allow_html=True)

def load_history():
    if HISTORY_PATH.exists():
        try:
            return pd.read_csv(HISTORY_PATH)
        except Exception:
            pass
    return pd.DataFrame(columns=["timestamp", "filename", "prediction", "confidence", "selected_bin", "result"])

def save_history(row):
    history = load_history()
    history = pd.concat([history, pd.DataFrame([row])], ignore_index=True)
    history.to_csv(HISTORY_PATH, index=False)

def classify_image(image):
    if not MODEL_PATH.exists() or not CLASS_PATH.exists():
        return None, None, "No trained model found yet."
    try:
        import numpy as np
        import tensorflow as tf
        model = tf.keras.models.load_model(MODEL_PATH)
        class_names = json.loads(CLASS_PATH.read_text(encoding="utf-8"))
        img = image.convert("RGB").resize((224, 224))
        arr = np.asarray(img, dtype="float32")
        arr = np.expand_dims(arr, axis=0)
        # The model includes MobileNetV2 preprocessing as its first layer.
        probs = model.predict(arr, verbose=0)[0]
        idx = int(np.argmax(probs))
        return class_names[idx], float(probs[idx]), None
    except Exception as e:
        return None, None, f"Could not load model: {e}"

def recommended_bin(category):
    if category in ("paper", "cardboard", "plastic"):
        return "recycling"
    return category

def main():
    with st.sidebar:
        st.markdown("## ♻️ WasteWise")
        st.caption("Sort today. Greener tomorrow.")
        page = st.radio("Navigate", ["Home", "Detect Waste", "My Progress", "Tips & Guide", "About"])
        st.divider()
        st.caption("AI predictions are estimates. Always follow your local waste rules.")

    st.markdown('<div class="hero"><h1>♻️ Waste Segregation Mistake Detector</h1><p>Upload a waste image, check your bin choice, and learn how to dispose of it more responsibly.</p></div>', unsafe_allow_html=True)

    history = load_history()
    if page == "Home":
        c1, c2, c3 = st.columns(3)
        total = len(history)
        correct = int((history["result"] == "Correct").sum()) if total else 0
        mistakes = int((history["result"] == "Mistake").sum()) if total else 0
        rate = (100 * correct / total) if total else 0
        c1.metric("Items checked", total)
        c2.metric("Correct bin choices", correct)
        c3.metric("Mistakes detected", mistakes)
        st.subheader("How it works")
        a, b, c = st.columns(3)
        a.info("**1. Upload**\n\nChoose a photo of one waste item.")
        b.info("**2. Detect**\n\nA trained image model predicts the waste category.")
        c.info("**3. Learn**\n\nCompare your chosen bin and see disposal tips.")
        st.subheader("Start a scan")
        st.write("Open **Detect Waste** in the sidebar to test an item.")
        if not MODEL_PATH.exists():
            st.warning("The app is ready, but automatic AI detection needs a trained model. Follow README.md to add a dataset and train it.")
        st.caption("Progress is saved locally in scan_history.csv on this computer.")

    elif page == "Detect Waste":
        left, right = st.columns([1, 1])
        with left:
            st.subheader("1. Upload a waste image")
            uploaded = st.file_uploader("Choose a JPG, JPEG, or PNG image", type=["jpg", "jpeg", "png"])
            if uploaded:
                try:
                    image = Image.open(uploaded).convert("RGB")
                    st.image(image, caption=uploaded.name, use_container_width=True)
                except Exception:
                    st.error("This image could not be opened. Try another JPG or PNG.")
                    image = None
            else:
                image = None
            st.subheader("2. Choose the bin you would use")
            selected_bin_label = st.selectbox("Your bin choice", list(BIN_OPTIONS.keys()))
            selected_bin = BIN_OPTIONS[selected_bin_label]
            demo_mode = not (MODEL_PATH.exists() and CLASS_PATH.exists())
            if demo_mode:
                st.info("Demo mode: no trained model is installed, so choose a sample prediction below. This is not automatic AI detection.")
                prediction = st.selectbox("Sample predicted category (demo only)", CLASSES)
                confidence = None
                error = None
            else:
                prediction, confidence, error = (None, None, None)
            check = st.button("🔎 Check segregation", type="primary", use_container_width=True)
        with right:
            st.subheader("Detection result")
            if check:
                if image is None:
                    st.error("Please upload an image first.")
                else:
                    if not demo_mode:
                        prediction, confidence, error = classify_image(image)
                    if error:
                        st.error(error)
                    elif prediction:
                        st.markdown(f"### Predicted category: **{prediction.title()}**")
                        if confidence is not None:
                            st.progress(min(max(confidence, 0.0), 1.0), text=f"Model confidence: {confidence:.1%}")
                        else:
                            st.caption("Demo prediction selected manually — no confidence score is available.")
                        expected = recommended_bin(prediction)
                        # Paper/cardboard/plastic share a broad recycling option; exact local rules vary.
                        correct = (selected_bin == expected) or (expected == "recycling" and selected_bin == "recycling")
                        if correct:
                            st.markdown('<div class="result-good"><h4>✅ Looks like a suitable choice</h4><p>Your selected bin is broadly consistent with the predicted category. Check local recycling rules.</p></div>', unsafe_allow_html=True)
                            result = "Correct"
                        else:
                            st.markdown(f'<div class="result-bad"><h4>⚠️ Possible segregation mistake</h4><p>For this prediction, consider: <b>{BIN_GUIDE[prediction]["bin"]}</b>.</p></div>', unsafe_allow_html=True)
                            result = "Mistake"
                        st.markdown("#### Disposal guidance")
                        for tip in BIN_GUIDE[prediction]["tips"]:
                            st.write(f"• {tip}")
                        save_history({
                            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "filename": uploaded.name,
                            "prediction": prediction,
                            "confidence": round(confidence, 4) if confidence is not None else "",
                            "selected_bin": selected_bin_label,
                            "result": result,
                        })
                        st.success("Scan saved to your local progress history.")
            else:
                st.info("Your prediction, bin check, and disposal tips will appear here after you press **Check segregation**.")
        st.caption("Important: this is an educational prototype, not a certified waste-management tool. Material type and local collection rules can vary.")

    elif page == "My Progress":
        st.subheader("Your scan history")
        if history.empty:
            st.info("No scans yet. Go to Detect Waste and check your first item.")
        else:
            total = len(history)
            correct = int((history["result"] == "Correct").sum())
            mistakes = int((history["result"] == "Mistake").sum())
            m1, m2, m3 = st.columns(3)
            m1.metric("Total scans", total)
            m2.metric("Correct choices", correct)
            m3.metric("Mistakes", mistakes)
            st.dataframe(history.sort_values("timestamp", ascending=False), use_container_width=True, hide_index=True)
            counts = history["prediction"].value_counts().rename_axis("Category").reset_index(name="Scans")
            st.bar_chart(counts.set_index("Category"))
            st.download_button("Download history as CSV", history.to_csv(index=False).encode("utf-8"), "wastewise_history.csv", "text/csv")
            if st.button("Clear local history"):
                HISTORY_PATH.unlink(missing_ok=True)
                st.rerun()

    elif page == "Tips & Guide":
        st.subheader("Quick waste-segregation guide")
        st.write("These are general suggestions. Local municipal rules take priority.")
        for category, info in BIN_GUIDE.items():
            with st.expander(f"{category.title()} — {info['bin']}"):
                for tip in info["tips"]:
                    st.write(f"• {tip}")
        st.info("Never place batteries, e-waste, chemicals, medicines, or sharps into ordinary recycling bins. Use an approved collection point.")

    else:
        st.subheader("About this capstone")
        st.write("**WasteWise: Waste Segregation Mistake Detector** is a student capstone prototype that combines image classification, bin-choice checking, disposal guidance, and personal progress tracking.")
        st.markdown("**What makes the project useful**")
        st.write("- Identifies a likely waste category from a photo when a trained model is installed.")
        st.write("- Checks whether the user's selected bin broadly matches the predicted category.")
        st.write("- Logs repeated choices so users can review common mistakes.")
        st.write("- Offers category-specific disposal tips.")
        st.markdown("**Honest limitation:** novelty is in combining these features into a learning workflow, not in claiming that waste image classification itself is new. Accuracy depends on dataset quality, image conditions, and local waste rules.")

if __name__ == "__main__":
    main()
