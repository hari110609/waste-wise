import json
from pathlib import Path
import tensorflow as tf

BASE = Path(__file__).parent
DATA_DIR = BASE / "data" / "waste_images"
MODEL_DIR = BASE / "models"
MODEL_DIR.mkdir(exist_ok=True)
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
SEED = 42

if not DATA_DIR.exists():
    raise SystemExit(f"Dataset folder not found: {DATA_DIR}")

train_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR, validation_split=0.2, subset="training", seed=SEED,
    image_size=IMG_SIZE, batch_size=BATCH_SIZE
)
val_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR, validation_split=0.2, subset="validation", seed=SEED,
    image_size=IMG_SIZE, batch_size=BATCH_SIZE
)
class_names = train_ds.class_names
print("Classes:", class_names)

AUTOTUNE = tf.data.AUTOTUNE
# Keep images in the 0–255 range here; preprocessing is included inside the model.
train_ds = train_ds.prefetch(AUTOTUNE)
val_ds = val_ds.prefetch(AUTOTUNE)

base_model = tf.keras.applications.MobileNetV2(
    input_shape=(224, 224, 3), include_top=False, weights="imagenet"
)
base_model.trainable = False
inputs = tf.keras.Input(shape=(224, 224, 3))
x = tf.keras.applications.mobilenet_v2.preprocess_input(inputs)
x = base_model(x, training=False)
x = tf.keras.layers.GlobalAveragePooling2D()(x)
x = tf.keras.layers.Dropout(0.2)(x)
outputs = tf.keras.layers.Dense(len(class_names), activation="softmax")(x)
model = tf.keras.Model(inputs, outputs)
model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])

callbacks = [
    tf.keras.callbacks.EarlyStopping(patience=3, restore_best_weights=True, monitor="val_loss"),
    tf.keras.callbacks.ModelCheckpoint(str(MODEL_DIR / "waste_classifier.keras"), save_best_only=True, monitor="val_loss")
]
model.fit(train_ds, validation_data=val_ds, epochs=12, callbacks=callbacks)
# Save final model as well, so the app can find it.
model.save(MODEL_DIR / "waste_classifier.keras")
(MODEL_DIR / "class_names.json").write_text(json.dumps(class_names), encoding="utf-8")
print("Training complete. Model saved in models/")
