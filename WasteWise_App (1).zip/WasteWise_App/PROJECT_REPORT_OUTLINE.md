# Capstone Report Outline — WasteWise

1. Title Page
2. Abstract
3. Introduction
4. Problem Statement
5. Objectives
6. Existing System and Limitations
7. Proposed System
8. System Requirements (hardware/software)
9. System Architecture
10. Dataset Collection and Preparation
11. Model Selection: MobileNetV2 Transfer Learning
12. Application Design and Modules
13. Implementation
14. Testing Plan
15. Evaluation Metrics and Results
16. Limitations and Ethical/Environmental Considerations
17. Future Enhancements
18. Conclusion
19. References

Do not fill the results chapter with invented values. Add measured test accuracy, class counts, and example results only after you run the model and test it.
