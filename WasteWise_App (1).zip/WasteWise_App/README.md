# WasteWise — Waste Segregation Mistake Detector

A beginner-friendly Python/Streamlit capstone prototype.

## Features
- Upload a photo of a waste item.
- Predict a category using a trained TensorFlow image classifier.
- Compare the predicted category with the bin the user selected.
- Show general disposal guidance.
- Save scan history locally and show progress.
- Export scan history to CSV.

## Important: what works immediately?
The interface runs immediately in **Demo mode** without a trained model. In Demo mode, you must select a sample predicted category yourself; it does NOT claim to recognise the image automatically. To enable automatic prediction, train a model using a labelled dataset.

## Setup on Windows / VS Code
1. Install Python 3.10 or 3.11 from python.org and tick **Add Python to PATH**.
2. Extract this ZIP.
3. Open the extracted `WasteWise_App` folder in VS Code.
4. Open Terminal → New Terminal.
5. Create and activate a virtual environment:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run this once for the current terminal:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

6. Install packages:
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

7. Start the app:
```powershell
streamlit run app.py
```
The app opens in your browser. You can explore Demo mode now.

## Turn on automatic AI image detection
Create folders like this, with labelled images inside each category folder:

```text
data/
  waste_images/
    cardboard/
    glass/
    metal/
    paper/
    plastic/
    trash/
    organic/
```

Use images you have permission to use. Each category should contain enough varied images for a meaningful experiment; a few images per class are not enough for a reliable model. Keep separate test images that are not used during training if you want a fair evaluation.

Then train:
```powershell
python train_model.py
```
The model is saved under `models/`. Restart the Streamlit app. The Detect Waste page will then use the model automatically.

## Suggested evaluation for your report
- Gather a labelled dataset and describe its source and class counts.
- Hold out test images that were not used for training.
- Report test accuracy and a confusion matrix; do not report training accuracy as test accuracy.
- Test photos with different backgrounds, lighting, angles, and item conditions.
- Record limitations: mixed-material items, local municipal rules, model bias, and incorrect predictions.

## Category mapping caveat
Waste rules vary by city and collection service. This prototype uses broad educational mappings, not a universal rule. In a real deployment, configure the bin mapping to match your municipality.

## Project title
**WasteWise: Waste Segregation Mistake Detector**

Novelty should be presented honestly: the capstone combines image classification, bin-choice checking, practical guidance, and progress tracking into one educational workflow. Do not claim that waste classification itself is a new invention.
